package com.secretary.secretaryapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SecretaryAppApplication {

    public static void main(String[] args) {
        SpringApplication.run(SecretaryAppApplication.class, args);
    }

}
