package com.secretary.secretaryapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SecretaryAppApplicationTests {

    @Test
    void contextLoads() {
    }

}
